import { Tabs } from "expo-router";
import { CakeSlice } from 'lucide-react-native';


export default function RootLayout() {
  return (
    <Tabs>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Receitas (fetch)',
          tabBarLabel: 'Fetch',
          tabBarIcon: ({ color, size }) => (
            <CakeSlice size={size} color={color} />
          )
        }}
      />
    </Tabs>
  );
}
