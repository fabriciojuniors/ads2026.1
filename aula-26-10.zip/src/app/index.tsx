import { useReceitasFetch } from "@/hook/useReceitasFetch";
import { Receita } from "@/types/receita";
import { useEffect, useState } from "react";
import { FlatList, StyleSheet, Text, View } from "react-native";

export default function Index() {
  const { listar } = useReceitasFetch();
  const [receitas, setReceitas] = useState<Receita[]>([]);

  const carregarReceitas = async () => {
    const resposta = await listar()
    setReceitas(resposta);
  }

  useEffect(() => {
    carregarReceitas()
  }, [])


  return (
    <View style={styles.container}>
      <FlatList
        data={receitas}
        renderItem={({ item }) => (
          <View>
            <Text>{item.id} - {item.nome}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 15
  },
});
